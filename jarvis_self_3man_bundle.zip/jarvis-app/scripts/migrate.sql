-- Base tables (creators etc already exists from older migrate)
-- Run in Neon SQL Editor: copy paste this whole file once
CREATE TABLE IF NOT EXISTS user_vault (
  user_id TEXT PRIMARY KEY,
  tier TEXT DEFAULT 'none',
  pod_id TEXT,
  scripts INT DEFAULT 0,
  streak INT DEFAULT 0,
  posts_7d INT DEFAULT 0,
  last_post_at TIMESTAMP,
  last_agent_use TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS pods (
  pod_id TEXT PRIMARY KEY,
  name TEXT,
  member_count INT DEFAULT 0,
  streak INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS pod_members (
  pod_id TEXT,
  user_id TEXT,
  streak INT DEFAULT 0,
  posts_7d INT DEFAULT 0,
  last_post_at TIMESTAMP,
  PRIMARY KEY (pod_id, user_id)
);
CREATE TABLE IF NOT EXISTS retention_events (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  action TEXT,
  offer TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS wins (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  title TEXT,
  proof_url TEXT,
  views INT DEFAULT 0,
  verified BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS revenue_log (
  id TEXT PRIMARY KEY,
  source TEXT,
  amount NUMERIC,
  paid_at TIMESTAMP DEFAULT NOW()
);
-- Adaptable niches/pods branding — no hardcoded niches in app code, Grok WF1 writes here
CREATE TABLE IF NOT EXISTS solo_domains (
  id TEXT PRIMARY KEY,
  name TEXT,
  niche TEXT,
  brand_voice TEXT DEFAULT 'Vesper 20yo playful witty adaptive',
  youtube_channel_id TEXT,
  buffer_profile_ids TEXT,
  status TEXT DEFAULT 'active',
  created_at TIMESTAMP DEFAULT NOW()
);
ALTER TABLE solo_domains ADD COLUMN IF NOT EXISTS brand_voice TEXT;
ALTER TABLE solo_domains ADD COLUMN IF NOT EXISTS buffer_profile_ids TEXT;
CREATE TABLE IF NOT EXISTS app_config (
  key TEXT PRIMARY KEY,
  value TEXT,
  updated_at TIMESTAMP DEFAULT NOW()
);
-- Seed adaptable defaults (override via ADMIN_EMAIL /admin → Create Niche)
INSERT INTO app_config (key, value) VALUES ('niches_pool','Psychology,Dark Psychology,Marketing History,Mindset,Wolf Mindset,Consumerism,Self-Improvement,Finance Behavior') ON CONFLICT DO NOTHING;
INSERT INTO app_config (key, value) VALUES ('pages_count','5') ON CONFLICT DO NOTHING;
INSERT INTO app_config (key, value) VALUES ('threshold_ratio_green','50') ON CONFLICT DO NOTHING;
INSERT INTO app_config (key, value) VALUES ('threshold_er_green','5') ON CONFLICT DO NOTHING;
INSERT INTO app_config (key, value) VALUES ('whop_ladder','27+9+79+19') ON CONFLICT DO NOTHING;
-- Seed 6 pods Red..Purple max 5 each for pod accountability next (Good-Better-Best)
INSERT INTO pods (pod_id, name) VALUES ('pod_red','Pod Red'),('pod_blue','Pod Blue'),('pod_green','Pod Green'),('pod_yellow','Pod Yellow'),('pod_purple','Pod Purple'),('pod_teal','Pod Teal') ON CONFLICT DO NOTHING;

-- ============ 2026-10-31 · TEAM AUTH + INTERVIEW + FUNDING ============
-- 3 seats (owner / content / social). Passwords live in env, not here.
CREATE TABLE IF NOT EXISTS team_profiles (
  email TEXT PRIMARY KEY,
  name TEXT,
  role TEXT CHECK (role IN ('owner','content','social')),
  answers JSONB DEFAULT '{}'::jsonb,
  completeness INT DEFAULT 0,
  updated_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS team_profiles_role_idx ON team_profiles (role);

-- Every privileged action gets a row: who, what, when.
CREATE TABLE IF NOT EXISTS audit_log (
  id BIGSERIAL PRIMARY KEY,
  actor TEXT,
  action TEXT,
  detail JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS audit_log_created_idx ON audit_log (created_at DESC);

-- Monthly 14-day sequence assets (Growth Operator book). Content bodies live in R2; this is the index.
CREATE TABLE IF NOT EXISTS sequence_assets (
  id BIGSERIAL PRIMARY KEY,
  cycle TEXT,                     -- e.g. 2026-11
  day INT,                        -- 1..14
  phase TEXT CHECK (phase IN ('warm_up','value_delivery','money_days')),
  slide_no INT,
  headline TEXT,
  body TEXT,
  cta TEXT,
  asset_url TEXT,                 -- R2 object key
  prompt_hash TEXT,
  approved BOOL DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS sequence_assets_cycle_idx ON sequence_assets (cycle, day, slide_no);

-- Follower gate: TikTok + IG only start the sequence after 1,000 each.
CREATE TABLE IF NOT EXISTS follower_gate (
  platform TEXT PRIMARY KEY,
  followers INT DEFAULT 0,
  unlocked BOOL DEFAULT FALSE,
  unlocked_at TIMESTAMP,
  checked_at TIMESTAMP DEFAULT NOW()
);

-- Funding ledger: what the community pot did each month.
CREATE TABLE IF NOT EXISTS funding_ledger (
  id BIGSERIAL PRIMARY KEY,
  period TEXT,                    -- 2026-11
  circle_revenue NUMERIC DEFAULT 0,
  tools_paid NUMERIC DEFAULT 0,
  prizes_paid NUMERIC DEFAULT 0,
  annual_fund NUMERIC DEFAULT 0,
  reserve NUMERIC DEFAULT 0,
  note TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

INSERT INTO app_config (key, value) VALUES ('autopay_authority','not_granted') ON CONFLICT DO NOTHING;
INSERT INTO app_config (key, value) VALUES ('follower_gate_ig','1000') ON CONFLICT DO NOTHING;
INSERT INTO app_config (key, value) VALUES ('follower_gate_tiktok','1000') ON CONFLICT DO NOTHING;
INSERT INTO app_config (key, value) VALUES ('sequence_cadence','monthly') ON CONFLICT DO NOTHING;
INSERT INTO app_config (key, value) VALUES ('churn_alert_pct','2.0') ON CONFLICT DO NOTHING;
INSERT INTO app_config (key, value) VALUES ('niches_pool','Stickman Finance,Psychology,Dark Psychology,Marketing History,Mindset,Wolf Mindset,Consumerism,Self-Improvement,Finance Behavior') ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW();

INSERT INTO follower_gate (platform, followers, unlocked) VALUES ('instagram',0,false),('tiktok',0,false) ON CONFLICT DO NOTHING;

-- ── THE OPEN LEDGER (public proof) ────────────────────────────────────────────
-- Every real day of every real channel, including the failures.
-- Written by WF9 from Buffer/IG/TikTok/YT analytics. Read by the public /proof page
-- with a 24h lag so nothing can be edited after the fact.
CREATE TABLE IF NOT EXISTS public_ledger (
  id           BIGSERIAL PRIMARY KEY,
  brand        TEXT        NOT NULL,
  platform     TEXT        NOT NULL,
  day          INT         NOT NULL,
  views        BIGINT      NOT NULL DEFAULT 0,
  er_pct       NUMERIC(5,2) NOT NULL DEFAULT 0,
  comments     INT         NOT NULL DEFAULT 0,
  replies      INT         NOT NULL DEFAULT 0,
  posted       INT         NOT NULL DEFAULT 0,
  note         TEXT        DEFAULT '',
  recorded_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (brand, platform, day)
);
CREATE INDEX IF NOT EXISTS idx_public_ledger_day ON public_ledger (day DESC);

COMMENT ON TABLE public_ledger IS
  'Public proof ledger — shown on /proof. Never delete a bad day: hiding a failure destroys the only trust signal we have.';

-- ── THE 14-DAY CHALLENGE (trust engine: "DO") ────────────────────────────────
-- Free to join, expensive to finish. Cohorts run monthly (cohort = 'YYYY-MM').
-- Jarvis sends the daily action at 06:00, verifies links, scores, and invites finishers.
CREATE TABLE IF NOT EXISTS challenge_members (
  id          TEXT PRIMARY KEY,
  handle      TEXT        NOT NULL,
  niche       TEXT        NOT NULL,
  email       TEXT        DEFAULT '',
  joined_day  INT         NOT NULL DEFAULT 1,
  cohort      TEXT        NOT NULL,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (cohort, handle)
);
CREATE INDEX IF NOT EXISTS idx_challenge_members_cohort ON challenge_members (cohort);

CREATE TABLE IF NOT EXISTS challenge_checkins (
  member_id   TEXT        NOT NULL REFERENCES challenge_members(id) ON DELETE CASCADE,
  day         INT         NOT NULL CHECK (day BETWEEN 1 AND 14),
  link        TEXT        DEFAULT '',
  note        TEXT        DEFAULT '',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (member_id, day)
);

-- One row per member: the number the cohort board and the upgrade decision read.
CREATE TABLE IF NOT EXISTS challenge_scores (
  member_id   TEXT PRIMARY KEY REFERENCES challenge_members(id) ON DELETE CASCADE,
  checked_in  INT         NOT NULL DEFAULT 0,
  streak      INT         NOT NULL DEFAULT 0,
  score       INT         NOT NULL DEFAULT 0,
  status      TEXT        NOT NULL DEFAULT 'active',  -- active | quiet | finisher | dropped
  verdict     TEXT,                                    -- PASS | AMBER | RED (day 13)
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

COMMENT ON TABLE challenge_scores IS
  'Completion rate is the only predictor of upgrade. 10/14 days + a day-13 verdict = finisher.';
