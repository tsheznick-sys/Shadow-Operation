# SHADOW OPERATION AGENT KIT (SOA)
Hand this folder to an agent so it can run vet -> outreach drafts -> audit -> demand test -> product build -> 14-day launch -> optimize, with YOU only doing the human parts.

## Deploy (pick one)
1. Claude Project: paste 00_MASTER_SYSTEM_PROMPT.md into Project instructions. Upload everything else as knowledge.
2. Claude Code / Agent SDK: put this folder in a repo, rename 00 to CLAUDE.md, give the agent file + web access. State lives in templates/creator_tracker.csv and reference/learnings.md (agent updates both every session).
3. Any other agent framework: 00 = system prompt, prompts/* = tool-specific sub-prompts, tools/revenue_model.py = callable tool.

## What the agent does vs what YOU do
AGENT: scouting, vetting math, drafting every DM/email/reply, audit PDFs, demand-test copy, product builds, legal DRAFTS, 14-day caption packs, tracker, leak analysis, expansion research.
YOU (non-delegable): press send on outreach, take calls, sign/accept agreements, move money, approve any gate override, post nothing on a creator's behalf.

## Run order (week 1)
Day 1: fill reference/operator_context.md. Run /leaks on current pipeline.
Day 2-3: /scout 60 accounts in ONE niche -> /vet -> top 10.
Day 4-5: /prewarm top 10, /touch (you send max 20-30 DMs/day, from an aged account).
Day 6-7: /reply within 1 hour of any response, /audit only after a positive reply.
Never build before written commitment + passed demand test.

## Files
00_MASTER_SYSTEM_PROMPT.md   orchestrator + hard gates
prompts/01..09               sub-prompts (scout, outreach, audit, demand test, product, launch, ops, expansion, legal gate)
templates/                   tracker csv, commitment outline
reference/                   operator context, playbook digest + claims audit, benchmarks/sources, original module
tools/revenue_model.py       honest revenue ranges (naive vs comment-anchored vs funnel)
VERDICT.md                   brutal assessment + kill criteria
